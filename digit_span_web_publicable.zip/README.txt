# Digit Span Web

Este paquete contiene una versión web responsive del Digit Span Test.

## Publicación rápida con GitHub Pages
1. Crea un repositorio nuevo.
2. Sube `index.html` a la raíz.
3. En Settings > Pages selecciona la rama principal (main) y `/root`.
4. GitHub entregará una URL pública.

La página ya está conectada al Google Apps Script configurado durante el desarrollo.
